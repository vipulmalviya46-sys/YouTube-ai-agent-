"""Claude wrapper. With no ANTHROPIC_API_KEY it runs 'offline' and callers use their own fallbacks,
which lets the whole pipeline be smoke-tested without any network access."""
from __future__ import annotations

import json
import os
import re


class LLM:
    def __init__(self, model: str | None = None):
        self.model = model or os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
        self.client = None
        if os.getenv("ANTHROPIC_API_KEY"):
            import anthropic

            self.client = anthropic.Anthropic()

    @property
    def online(self) -> bool:
        return self.client is not None

    def complete(self, system: str, prompt: str, max_tokens: int = 4000) -> str:
        if not self.client:
            raise RuntimeError("LLM offline")
        msg = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")

    def json(self, system: str, prompt: str, fallback, max_tokens: int = 4000):
        """Ask for JSON; on any failure (offline, bad JSON) return `fallback`."""
        if not self.client:
            return fallback
        try:
            raw = self.complete(system + "\nReply with ONLY valid JSON, no prose, no code fences.", prompt, max_tokens)
            raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
            data = json.loads(raw)
            if isinstance(fallback, list) and isinstance(data, dict):  # Claude sometimes wraps: {"ideas": [...]}
                data = next((v for v in data.values() if isinstance(v, list)), fallback)
            return data
        except Exception as e:  # noqa: BLE001
            print(f"[llm] JSON call failed, using fallback: {e}")
            return fallback
